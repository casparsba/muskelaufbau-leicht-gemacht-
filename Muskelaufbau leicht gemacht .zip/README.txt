Muskelaufbau Pro – installierbare Web-App (PWA)

WICHTIG: Für „Zum Startbildschirm hinzufügen“ als echte App müssen diese Dateien über HTTPS bereitgestellt werden. Eine einzelne HTML-Datei oder das Öffnen direkt aus einem Download-Ordner reicht für PWA-Installation und Offline-Modus nicht zuverlässig aus.

Dateien:
- index.html: App
- manifest.webmanifest: Name, Darstellung und Startbildschirm-Einstellungen
- sw.js: Offline-Caching
- icon-192.png / icon-512.png: App-Symbole

Nach dem Hosting auf einer HTTPS-Adresse:
Android/Chrome: Menü ⋮ → „App installieren“ oder „Zum Startbildschirm hinzufügen“.
iPhone/Safari: Teilen → „Zum Home-Bildschirm“ → „Als Web-App öffnen“.

Die untere Navigation bleibt fest am unteren Bildschirmrand und berücksichtigt Safe-Areas.
